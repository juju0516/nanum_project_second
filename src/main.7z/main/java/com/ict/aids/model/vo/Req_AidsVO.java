package com.ict.aids.model.vo;

public class Req_AidsVO {
	
	private int	req_aids_idx;
	private String	id; 
	private String req_title; 
	private String name;
	private String req_content;
	private String req_date;
	private String req_state;
	private String manager_id;
	private String req_f_name1;
	private String req_f_name2; 
	private String req_f_name3;
	private String req_crtf_f_name1;
	private String req_crtf_f_name2;
	private String req_crtf_f_name3;
	private String req_crtf_f_name4;
	private String req_crtf_f_name5;
	
	
	
	// getter/ setter
	
	public int getReq_aids_idx() {
		return req_aids_idx;
	}
	public void setReq_aids_idx(int req_aids_idx) {
		this.req_aids_idx = req_aids_idx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getReq_title() {
		return req_title;
	}
	public void setReq_title(String req_title) {
		this.req_title = req_title;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getReq_content() {
		return req_content;
	}
	public void setReq_content(String req_content) {
		this.req_content = req_content;
	}
	public String getReq_date() {
		return req_date;
	}
	public void setReq_date(String req_date) {
		this.req_date = req_date;
	}
	public String getReq_state() {
		return req_state;
	}
	public void setReq_state(String req_state) {
		this.req_state = req_state;
	}
	public String getManager_id() {
		return manager_id;
	}
	public void setManager_id(String manager_id) {
		this.manager_id = manager_id;
	}
	public String getReq_f_name1() {
		return req_f_name1;
	}
	public void setReq_f_name1(String req_f_name1) {
		this.req_f_name1 = req_f_name1;
	}
	public String getReq_f_name2() {
		return req_f_name2;
	}
	public void setReq_f_name2(String req_f_name2) {
		this.req_f_name2 = req_f_name2;
	}
	public String getReq_f_name3() {
		return req_f_name3;
	}
	public void setReq_f_name3(String req_f_name3) {
		this.req_f_name3 = req_f_name3;
	}
	public String getReq_crtf_f_name1() {
		return req_crtf_f_name1;
	}
	public void setReq_crtf_f_name1(String req_crtf_f_name1) {
		this.req_crtf_f_name1 = req_crtf_f_name1;
	}
	public String getReq_crtf_f_name2() {
		return req_crtf_f_name2;
	}
	public void setReq_crtf_f_name2(String req_crtf_f_name2) {
		this.req_crtf_f_name2 = req_crtf_f_name2;
	}
	public String getReq_crtf_f_name3() {
		return req_crtf_f_name3;
	}
	public void setReq_crtf_f_name3(String req_crtf_f_name3) {
		this.req_crtf_f_name3 = req_crtf_f_name3;
	}
	public String getReq_crtf_f_name4() {
		return req_crtf_f_name4;
	}
	public void setReq_crtf_f_name4(String req_crtf_f_name4) {
		this.req_crtf_f_name4 = req_crtf_f_name4;
	}
	public String getReq_crtf_f_name5() {
		return req_crtf_f_name5;
	}
	public void setReq_crtf_f_name5(String req_crtf_f_name5) {
		this.req_crtf_f_name5 = req_crtf_f_name5;
	}

	

	


}
