package com.ict.project.model.vo;

public class DonatorVO {
	private int		donator_idx;
	private int		project_idx;
	private String	prj_name;
	private String	id;
	private String	regular;
	private int		r_count;
	private String	onetime;
	private int		o_count;
	private String	dnt_date;
	private int		dnt_point;
	private String	dnt_flag;
	private String	vlt_flag;
	private int		vlt_count;
	
	public int getDonator_idx() {
		return donator_idx;
	}
	public void setDonator_idx(int donator_idx) {
		this.donator_idx = donator_idx;
	}
	public int getProject_idx() {
		return project_idx;
	}
	public void setProject_idx(int project_idx) {
		this.project_idx = project_idx;
	}
	public String getPrj_name() {
		return prj_name;
	}
	public void setPrj_name(String prj_name) {
		this.prj_name = prj_name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRegular() {
		return regular;
	}
	public void setRegular(String regular) {
		this.regular = regular;
	}
	public int getR_count() {
		return r_count;
	}
	public void setR_count(int r_count) {
		this.r_count = r_count;
	}
	public String getOnetime() {
		return onetime;
	}
	public void setOnetime(String onetime) {
		this.onetime = onetime;
	}
	public int getO_count() {
		return o_count;
	}
	public void setO_count(int o_count) {
		this.o_count = o_count;
	}
	public String getDnt_date() {
		return dnt_date;
	}
	public void setDnt_date(String dnt_date) {
		this.dnt_date = dnt_date;
	}
	public int getDnt_point() {
		return dnt_point;
	}
	public void setDnt_point(int dnt_point) {
		this.dnt_point = dnt_point;
	}
	public String getDnt_flag() {
		return dnt_flag;
	}
	public void setDnt_flag(String dnt_flag) {
		this.dnt_flag = dnt_flag;
	}
	public String getVlt_flag() {
		return vlt_flag;
	}
	public void setVlt_flag(String vlt_flag) {
		this.vlt_flag = vlt_flag;
	}
	public int getVlt_count() {
		return vlt_count;
	}
	public void setVlt_count(int vlt_count) {
		this.vlt_count = vlt_count;
	}
}
