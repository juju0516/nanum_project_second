package com.ict.stroy.model.vo;

public class StoryVO {
	
	private int	story_idx;
	private int	story_hit;
	private String manager_id;
	private String story_category;
	private String story_title;
	private String story_content;
	private String story_date;
	private String s_state;
	private String story_f_name1;
	private String story_f_name2;
	private String story_f_name3;
	
	
	//get / set
	
	
	public int getStory_idx() {
		return story_idx;
	}
	public void setStory_idx(int story_idx) {
		this.story_idx = story_idx;
	}
	public int getStory_hit() {
		return story_hit;
	}
	public void setStory_hit(int story_hit) {
		this.story_hit = story_hit;
	}
	public String getManager_id() {
		return manager_id;
	}
	public void setManager_id(String manager_id) {
		this.manager_id = manager_id;
	}
	public String getStory_category() {
		return story_category;
	}
	public void setStory_category(String story_category) {
		this.story_category = story_category;
	}
	public String getStory_title() {
		return story_title;
	}
	public void setStory_title(String story_title) {
		this.story_title = story_title;
	}
	public String getStory_content() {
		return story_content;
	}
	public void setStory_content(String story_content) {
		this.story_content = story_content;
	}
	public String getStory_date() {
		return story_date;
	}
	public void setStory_date(String story_date) {
		this.story_date = story_date;
	}
	public String getS_state() {
		return s_state;
	}
	public void setS_state(String s_state) {
		this.s_state = s_state;
	}
	public String getStory_f_name1() {
		return story_f_name1;
	}
	public void setStory_f_name1(String story_f_name1) {
		this.story_f_name1 = story_f_name1;
	}
	public String getStory_f_name2() {
		return story_f_name2;
	}
	public void setStory_f_name2(String story_f_name2) {
		this.story_f_name2 = story_f_name2;
	}
	public String getStory_f_name3() {
		return story_f_name3;
	}
	public void setStory_f_name3(String story_f_name3) {
		this.story_f_name3 = story_f_name3;
	}
	


	
	
}
