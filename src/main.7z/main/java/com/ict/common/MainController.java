package com.ict.common;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class MainController {

	@RequestMapping("main_page.do")
	public ModelAndView getMainPage() {
		return new ModelAndView("main_page");
	}
	/*
	 * @RequestMapping("main_page_logout.do") public ModelAndView
	 * getMainPageLogOut() { return new ModelAndView("main_page"); }
	 */
}
