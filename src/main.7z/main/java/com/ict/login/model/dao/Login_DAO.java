package com.ict.login.model.dao;

import java.util.HashMap;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ict.member.model.vo.MemberVO;

@Repository
public class Login_DAO {
	@Autowired
	private SqlSessionTemplate sqlSessionTemplate;

	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}
	
	// 로그인
	public MemberVO getMemberLogin(MemberVO mvo) {
		return sqlSessionTemplate.selectOne("login_mapper.login", mvo);
	}
	
	// 회원가입
	public int getMemberJoin(MemberVO mvo) {
		return sqlSessionTemplate.insert("login_mapper.sign_up", mvo);
	}
	
	// 회원가입 정보 업데이트
	public int getMemberAdd(MemberVO mvo) {
		//Map<String, String> map = new HashMap<String, String>();
		//map.put("nickname", nickname);
		//map.put("address", address);
		/*
		 * map.put("sample3_address", sample3_address); map.put("sample3_detailAddress",
		 * sample3_detailAddress); map.put("sample3_extraAddress",
		 * sample3_extraAddress);
		 */
		return sqlSessionTemplate.update("login_mapper.update", mvo);
	}
	
	// 아이디 가져오기
	public MemberVO getSignId(String id) {
		return sqlSessionTemplate.selectOne("login_mapper.getid", id);
	}
	
	// 아이디 체크하기
	public int checkId(String id) {
		return sqlSessionTemplate.selectOne("login_mapper.checkid", id);
	}
	
	// 패스워드 체크하기
	public String checkPw(String pw) {
		return sqlSessionTemplate.selectOne("login_mapper.checkpw", pw);
	}

	
}
