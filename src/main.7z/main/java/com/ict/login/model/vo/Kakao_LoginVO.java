package com.ict.login.model.vo;

public class Kakao_LoginVO {
	private int		kakao_login_idx;
	private String	kakao_uid;
	private String	kakao_pw;
	
	public int getKakao_login_idx() {
		return kakao_login_idx;
	}
	public void setKakao_login_idx(int kakao_login_idx) {
		this.kakao_login_idx = kakao_login_idx;
	}
	public String getKakao_uid() {
		return kakao_uid;
	}
	public void setKakao_uid(String kakao_uid) {
		this.kakao_uid = kakao_uid;
	}
	public String getKakao_pw() {
		return kakao_pw;
	}
	public void setKakao_pw(String kakao_pw) {
		this.kakao_pw = kakao_pw;
	}
}

