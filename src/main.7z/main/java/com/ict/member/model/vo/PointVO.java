package com.ict.member.model.vo;

public class PointVO {
	private String id, p_category, req_name, req_p_date, p_state, accept_date, deduct_date, refund_date, manager_id;
	private int point_idx, remain_point, req_money, req_point, deduct_point, refund_point;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getP_category() {
		return p_category;
	}
	public void setP_category(String p_category) {
		this.p_category = p_category;
	}
	public String getReq_name() {
		return req_name;
	}
	public void setReq_name(String req_name) {
		this.req_name = req_name;
	}
	public String getReq_p_date() {
		return req_p_date;
	}
	public void setReq_p_date(String req_p_date) {
		this.req_p_date = req_p_date;
	}
	public String getP_state() {
		return p_state;
	}
	public void setP_state(String p_state) {
		this.p_state = p_state;
	}
	public String getAccept_date() {
		return accept_date;
	}
	public void setAccept_date(String accept_date) {
		this.accept_date = accept_date;
	}
	public String getDeduct_date() {
		return deduct_date;
	}
	public void setDeduct_date(String deduct_date) {
		this.deduct_date = deduct_date;
	}
	public String getRefund_date() {
		return refund_date;
	}
	public void setRefund_date(String refund_date) {
		this.refund_date = refund_date;
	}
	public String getManager_id() {
		return manager_id;
	}
	public void setManager_id(String manager_id) {
		this.manager_id = manager_id;
	}
	public int getPoint_idx() {
		return point_idx;
	}
	public void setPoint_idx(int point_idx) {
		this.point_idx = point_idx;
	}
	public int getRemain_point() {
		return remain_point;
	}
	public void setRemain_point(int remain_point) {
		this.remain_point = remain_point;
	}
	public int getReq_money() {
		return req_money;
	}
	public void setReq_money(int req_money) {
		this.req_money = req_money;
	}
	public int getReq_point() {
		return req_point;
	}
	public void setReq_point(int req_point) {
		this.req_point = req_point;
	}
	public int getDeduct_point() {
		return deduct_point;
	}
	public void setDeduct_point(int deduct_point) {
		this.deduct_point = deduct_point;
	}
	public int getRefund_point() {
		return refund_point;
	}
	public void setRefund_point(int refund_point) {
		this.refund_point = refund_point;
	}

}
