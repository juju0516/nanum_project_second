package com.ict.member.model.vo;

public class InquiryVO {
	private String id, inq_category, inq_title, inq_content, inq_f_name1, inq_f_name2, inq_f_name3, inq_f_name4,
			inq_f_name5, manager_id;
	private int inquiry_idx, groups, step, lev;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getInq_category() {
		return inq_category;
	}
	public void setInq_category(String inq_category) {
		this.inq_category = inq_category;
	}
	public String getInq_title() {
		return inq_title;
	}
	public void setInq_title(String inq_title) {
		this.inq_title = inq_title;
	}
	public String getInq_content() {
		return inq_content;
	}
	public void setInq_content(String inq_content) {
		this.inq_content = inq_content;
	}
	public String getInq_f_name1() {
		return inq_f_name1;
	}
	public void setInq_f_name1(String inq_f_name1) {
		this.inq_f_name1 = inq_f_name1;
	}
	public String getInq_f_name2() {
		return inq_f_name2;
	}
	public void setInq_f_name2(String inq_f_name2) {
		this.inq_f_name2 = inq_f_name2;
	}
	public String getInq_f_name3() {
		return inq_f_name3;
	}
	public void setInq_f_name3(String inq_f_name3) {
		this.inq_f_name3 = inq_f_name3;
	}
	public String getInq_f_name4() {
		return inq_f_name4;
	}
	public void setInq_f_name4(String inq_f_name4) {
		this.inq_f_name4 = inq_f_name4;
	}
	public String getInq_f_name5() {
		return inq_f_name5;
	}
	public void setInq_f_name5(String inq_f_name5) {
		this.inq_f_name5 = inq_f_name5;
	}
	public String getManager_id() {
		return manager_id;
	}
	public void setManager_id(String manager_id) {
		this.manager_id = manager_id;
	}
	public int getInquiry_idx() {
		return inquiry_idx;
	}
	public void setInquiry_idx(int inquiry_idx) {
		this.inquiry_idx = inquiry_idx;
	}
	public int getGroups() {
		return groups;
	}
	public void setGroups(int groups) {
		this.groups = groups;
	}
	public int getStep() {
		return step;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public int getLev() {
		return lev;
	}
	public void setLev(int lev) {
		this.lev = lev;
	}
}
