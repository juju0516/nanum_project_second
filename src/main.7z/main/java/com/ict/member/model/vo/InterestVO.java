package com.ict.member.model.vo;

public class InterestVO {
	private String id, alarm;
	private int interest_idx, project_idx;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getAlarm() {
		return alarm;
	}
	public void setAlarm(String alarm) {
		this.alarm = alarm;
	}
	public int getInterest_idx() {
		return interest_idx;
	}
	public void setInterest_idx(int interest_idx) {
		this.interest_idx = interest_idx;
	}
	public int getProject_idx() {
		return project_idx;
	}
	public void setProject_idx(int project_idx) {
		this.project_idx = project_idx;
	}
}
