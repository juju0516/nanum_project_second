package com.ict.member.controller;

import java.io.IOException;
import java.net.http.HttpResponse;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ict.member.model.vo.MemberVO;

@Controller
public class Member_Controller {

	@RequestMapping("member_mypage.do")
	public ModelAndView getMyPage() {
		return new ModelAndView("member/member_mypage");
	}

	@RequestMapping("member_point.do")
	public ModelAndView getPoint() {
		return new ModelAndView("member/member_point");
	}

	@RequestMapping("member_like_list.do")
	public ModelAndView getLikeList() {
		return new ModelAndView("member/member_like_list");
	}

	@RequestMapping("member_donate.do")
	public ModelAndView getDonate() {
		return new ModelAndView("member/member_donate");
	}

	@RequestMapping("member_inquiry.do")
	public ModelAndView getInquiry() {
		return new ModelAndView("member/member_inquiry");
	}

	@RequestMapping("member_inquiry_onelist.do")
	public ModelAndView getInquiryOnelist() {
		return new ModelAndView("member/member_inquiry_onelist");
	}

	@RequestMapping("member_inquiry_onelist_ans.do")
	public ModelAndView getInquiryOnelistAns() {
		return new ModelAndView("member/member_inquiry_onelist_ans");
	}

	@RequestMapping("member_regular_list.do")
	public ModelAndView getRegularList() {
		return new ModelAndView("member/member_regular_list");
	}

	@RequestMapping("member_special_donate.do")
	public ModelAndView getAnniDonate() {
		return new ModelAndView("member/member_special_donate");
	}

	@RequestMapping("member_project_status.do")
	public ModelAndView getProjectStatus() {
		return new ModelAndView("member/member_project_status");
	}

	@RequestMapping("member_req_aids.do")
	public ModelAndView getChangeInfo() {
		return new ModelAndView("member/member_req_aids");
	}

	@RequestMapping("member_goods_list.do")
	public ModelAndView getReqAids() {
		return new ModelAndView("member/member_goods_list");
	}

	@RequestMapping("member_change_info.do")
	public ModelAndView getGoodsList() {
		return new ModelAndView("member/member_change_info");
	}

	@RequestMapping("member_point_change.do")
	public ModelAndView getPointChange() {
		return new ModelAndView("member/member_point_change");
	}

	@RequestMapping("member_nanumi_change_list.do")
	public ModelAndView getNanumiChangeList() {
		return new ModelAndView("member/member_nanumi_change_list");
	}

	@RequestMapping("member_point_change_ok.do")
	public ModelAndView getPointChangeOk() {
		return new ModelAndView("member/member_point_change_ok");
	}

	@RequestMapping("member_delete_account.do")
	public ModelAndView getDeleteAccount() {
		return new ModelAndView("member/member_delete_account");
	}

	@RequestMapping("member_delete_account_ok.do")
	public ModelAndView getDeleteAccountOk() {
		return new ModelAndView("member/member_delete_account_ok");
	}

	@RequestMapping("member_delete_reason.do")
	public ModelAndView getDeleteProject() {
		return new ModelAndView("member/member_delete_reason");
	}

	@RequestMapping("member_main_page_logout.do")
	public ModelAndView getLogout(HttpServletRequest request) {
		ModelAndView mv = new ModelAndView();

		// 1: 기존의 세션 데이터를 모두 삭제
		// session.invalidate();

		// 1. .removeAttribute() 사용
		HttpSession session = request.getSession();

		if (session != null) {
			session.removeAttribute("memberID");
			session.removeAttribute("login");
			return new ModelAndView("redirect:main_page.do");
		} else {
			return mv;
		}

		// 2: 로그인 페이지로 이동시킴.
		// return new ModelAndView("main_page");
	}

}
