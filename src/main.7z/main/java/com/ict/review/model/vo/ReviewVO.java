package com.ict.review.model.vo;

public class ReviewVO {
	private int		review_idx;
	private String	id;
	private String	re_title;
	private String	nickname;
	private String	re_content;
	private String	re_f_name1;
	private String	re_f_name2;
	private String	re_f_name3;
	private String	re_f_name4;
	private String	re_f_name5;
	private String	re_date;
	private int		re_hit;
	private String	re_state;
	
	public int getReview_idx() {
		return review_idx;
	}
	public void setReview_idx(int review_idx) {
		this.review_idx = review_idx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getRe_title() {
		return re_title;
	}
	public void setRe_title(String re_title) {
		this.re_title = re_title;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	public String getRe_content() {
		return re_content;
	}
	public void setRe_content(String re_content) {
		this.re_content = re_content;
	}
	public String getRe_f_name1() {
		return re_f_name1;
	}
	public void setRe_f_name1(String re_f_name1) {
		this.re_f_name1 = re_f_name1;
	}
	public String getRe_f_name2() {
		return re_f_name2;
	}
	public void setRe_f_name2(String re_f_name2) {
		this.re_f_name2 = re_f_name2;
	}
	public String getRe_f_name3() {
		return re_f_name3;
	}
	public void setRe_f_name3(String re_f_name3) {
		this.re_f_name3 = re_f_name3;
	}
	public String getRe_f_name4() {
		return re_f_name4;
	}
	public void setRe_f_name4(String re_f_name4) {
		this.re_f_name4 = re_f_name4;
	}
	public String getRe_f_name5() {
		return re_f_name5;
	}
	public void setRe_f_name5(String re_f_name5) {
		this.re_f_name5 = re_f_name5;
	}
	public String getRe_date() {
		return re_date;
	}
	public void setRe_date(String re_date) {
		this.re_date = re_date;
	}
	public int getRe_hit() {
		return re_hit;
	}
	public void setRe_hit(int re_hit) {
		this.re_hit = re_hit;
	}
	public String getRe_state() {
		return re_state;
	}
	public void setRe_state(String re_state) {
		this.re_state = re_state;
	}
}
