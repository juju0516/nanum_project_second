package com.ict.special.model.vo;

public class Special_DonateVO {
	
	private int	special_donate_idx;
	private int s_dnt_point;
	private int s_r_count;
	private String id;
	private String type;
	private String target_name;
	private String s_dnt_date;
	private String regular;
	private String r_dnt_date;
	private String onetime;
	private String regi_date;
	
	// get / set
	
	public int getSpecial_donate_idx() {
		return special_donate_idx;
	}
	public void setSpecial_donate_idx(int special_donate_idx) {
		this.special_donate_idx = special_donate_idx;
	}
	public int getS_dnt_point() {
		return s_dnt_point;
	}
	public void setS_dnt_point(int s_dnt_point) {
		this.s_dnt_point = s_dnt_point;
	}
	public int getS_r_count() {
		return s_r_count;
	}
	public void setS_r_count(int s_r_count) {
		this.s_r_count = s_r_count;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTarget_name() {
		return target_name;
	}
	public void setTarget_name(String target_name) {
		this.target_name = target_name;
	}
	public String getS_dnt_date() {
		return s_dnt_date;
	}
	public void setS_dnt_date(String s_dnt_date) {
		this.s_dnt_date = s_dnt_date;
	}
	public String getRegular() {
		return regular;
	}
	public void setRegular(String regular) {
		this.regular = regular;
	}
	public String getR_dnt_date() {
		return r_dnt_date;
	}
	public void setR_dnt_date(String r_dnt_date) {
		this.r_dnt_date = r_dnt_date;
	}
	public String getOnetime() {
		return onetime;
	}
	public void setOnetime(String onetime) {
		this.onetime = onetime;
	}
	public String getRegi_date() {
		return regi_date;
	}
	public void setRegi_date(String regi_date) {
		this.regi_date = regi_date;
	}
	
	
	

}
